#The purpose of this program is to solve problems using equations of motion and spit out answers and methodology
def calculator():#defines all the following as a function
    equation_of_motion=input("What equation of motion would you like to use?(1, 2, or 3):")#Asks the user what equation of motion they'd like to use

    if equation_of_motion=="1":#Uses the first equation of motion to solve problems
        initial_velocity=input("What is the initial velocity?(numbers only):")
        acceleration=input("What is the acceleration?(numbers only):")
        change_of_time=input("What is the change of time(numbers only):")
        final_velocity=float(acceleration)*float(change_of_time)+float(initial_velocity)
        print("Your final velocity is equal to " +str(acceleration)+"*"+str(change_of_time)+"+"+str(initial_velocity))
        print("Your final velocity is:"+str(final_velocity))

    if equation_of_motion=="2":#Uses the second equation of motion to solve problems
        initial_velocity=input("What is the initial velocity?(numbers only):")
        acceleration=input("What is the acceleration?(numbers only):")
        change_of_time=input("What is the change of time(numbers only):")
        displacement=float(initial_velocity)*float(change_of_time)+(0.5 *float(acceleration)*float(change_of_time)*float(change_of_time))
        print("Your displacement is equal to "+str(change_of_time)+"+1/2"+"("+str(acceleration)+"*"+str(change_of_time)+"*"+str(change_of_time)+")")
        print("Your displacemnt is:"+str(displacement))
    
    if equation_of_motion=="3":#Uses the third equation of motion to solve problems
              initial_velocity=input("What is the initial velocity(numbers only):")
              final_velocity=input("What is the final velocity(numbers only):")
              acceleration=input("What is the accleration(numbers only):")
              displacement=((float(final_velocity)*float(final_velocity))-(float(initial_velocity)*float(initial_velocity)))/(2*float(acceleration))
              print("Your displacement is equal to ("+str(final_velocity)+"*"+str(final_velocity)+")-("+str(initial_velocity)+"*"+str(initial_velocity)+"divided by 2")
              print("Your displacement is equal:"+str(displacement))
    
    
calculator()#runs the function
calculate_again=input("Do you want to do another calculation?(yes or no)")#asks the user if he/she wants to do another calculation for the first time
while calculate_again=="yes":#loops it as long as the user needs to use it
    calculator()
    calculate_again=input("Do you want to do another calculation?(yes or no)")
if calculate_again=="no":#ends the program when the user is finished with the code
    quit()



    
